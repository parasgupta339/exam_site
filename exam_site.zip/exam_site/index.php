<?php
include 'common.php';
echo $twig->render('index.html');
?>